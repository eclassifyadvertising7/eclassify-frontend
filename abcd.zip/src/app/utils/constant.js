const baseUrl = "http://localhost:6500";

export default baseUrl;