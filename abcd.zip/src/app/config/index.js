

export const initialSignInFormData = {
  userEmail: "",
  password: ""
};

export const initialSignUpFormData = {
  fullName: "",
  userEmail: "",
  password: "",
  RegisteredType: "",
  
};
export const initialUpdateFormData = {
  
  gender : "",
  dateOfBirth: "",
  State: "",
  Address: "",
  Pincode: "",
  maritalStatus: "",
  mobileNumber: "",
  district: "",
  PANCardNo: "",
  // instituteName
  instituteName:"",
  instituteBio:"",
  instituteCategory:"",
  Country:"",
  websiteUrl:"",
  profileImage:""

}