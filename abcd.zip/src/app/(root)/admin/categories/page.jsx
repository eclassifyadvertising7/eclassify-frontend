import CategoriesManagement from "@/components/admin/categories-management"

export default function CategoriesPage() {
  return (
    <div className="space-y-6">
      <CategoriesManagement />
    </div>
  )
}
