import AdsManagement from "@/components/admin/ads-management"

export default function AdsPage() {
  return <AdsManagement />
}
