export default function ReportsPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Reports</h2>
      <p className="text-gray-600">Reports coming soon...</p>
    </div>
  )
}
