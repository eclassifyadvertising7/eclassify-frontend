import DashboardStats from "@/components/admin/dashboard-stats"

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      <DashboardStats />
    </div>
  )
}
