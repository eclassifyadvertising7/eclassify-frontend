import UsersManagement from "@/components/admin/users-management"

export default function UsersPage() {
  return <UsersManagement />
}
