import SubscriptionForm from "@/components/admin/subscription-form"

export default function CreateSubscriptionPage() {
  return <SubscriptionForm mode="create" />
}
