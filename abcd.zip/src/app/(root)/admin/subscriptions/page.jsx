import SubscriptionPlans from "@/components/admin/packeges"

export default function SubscriptionsPage() {
  return <SubscriptionPlans />
}
