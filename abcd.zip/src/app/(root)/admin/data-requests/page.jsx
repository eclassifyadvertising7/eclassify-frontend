import DataRequestsManagement from "@/components/admin/data-requests-management"

export default function DataRequestsPage() {
  return <DataRequestsManagement />
}
