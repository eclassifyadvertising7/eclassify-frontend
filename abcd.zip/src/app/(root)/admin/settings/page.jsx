export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Settings</h2>
      <p className="text-gray-600">Settings coming soon...</p>
    </div>
  )
}
