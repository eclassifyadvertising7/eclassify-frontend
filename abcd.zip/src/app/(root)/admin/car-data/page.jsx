import CarDataManagement from "@/components/admin/car-data-management"

export default function CarDataPage() {
  return <CarDataManagement />
}
