import AdminProfile from "@/components/admin/admin-profile"

export default function AdminProfilePage() {
  return <AdminProfile />
}
